from flask import Flask,jsonify
from flask import render_template
from crawl_task import run,baseUrl,cursor


app = Flask(__name__)

@app.route("/<username>")
def hello_world(username):
    return f"<h1>Hello Flask ! Hello {username}"


@app.route("/data/<city>/<query>")
def data(city="101",query="大数据"):
    run(f"{baseUrl}/{city}/?query={query}&page=1",True)
    cursor.execute("select * from boss_pos")
    data = cursor.fetchall()
    return jsonify(data)


@app.route("/")
def index():
    return render_template("index.html")
