
from requests import get
from bs4 import BeautifulSoup
import pymysql
from header import cookie


baseUrl = "https://www.zhipin.com"
db = pymysql.connect(host='127.0.0.1', user='root', password="root",database ='boot_crm')  
cursor = db.cursor()
# parser
def parser(response): 
  list = []
  soup = BeautifulSoup(response.text, "lxml")
  if(len(soup.select(".page .next"))==0):
    print("AUTH FAIED !")
    return
  nextHref = soup.select(".page .next")[0]['href']
  allJobs = soup.select('li .job-primary')
  if(len(allJobs)==0):
    print("Jobs is Zore")
    return
  for job in allJobs:
    data = parserOne(job)
    list.append(data)
  saveDB(list)
  print("保存成功！")
  if nextHref == 'javascript:;':
    print("Not Next Page")
    return
  
  run(baseUrl+nextHref)

# 解析一个
def parserOne(job):
  soup = BeautifulSoup(str(job), "lxml")
  if(len(soup.select('.job-name')) == 0): return
  name = soup.select('.job-name')[0].find('a').text
  company = soup.select('.company-text')[0].find('a').text
  salary = soup.select('.job-limit ')[0].find('span').text
  edu = soup.select('.job-limit')[0].find('p').text
  data = {
    'name': name,
    'company': company,
    'salary': salary,
    'edu': edu,
  }
  return data

# save to db
def saveDB(list):
  '''保存每一页的数据到数据库中'''
  # db = pymysql.connect(host='127.0.0.1', user='root', password="root",database ='boot_crm')  
  # cursor = db.cursor()
  for i in range(len(list)):
    item = list[i]
    print
    sql = f"insert into boss_pos(`name`,`company`,`salary`,`edu`) values('{item['name']}','{item['company']}','{item['salary']}','{item['edu']}');"
    try:
      cursor.execute(sql)
    except pymysql.Error as e:
      print("数据库出错", e)
      db.rollback()
    else:
      db.commit()


# run
def run(url,clear=False):
  if clear:
      clearSql = f"delete from boss_pos"
      cursor.execute(clearSql)
  headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'zh-CN,zh;q=0.9',
    'cache-control': 'no-cache',
    'cookie': cookie,
    'pragma': 'no-cache',
    'sec-ch-ua': '"Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
  }
  r = get(url,headers=headers)
  parser(r)



# run(f"{baseUrl}/c100010000/?query=大数据&page=1",True)

